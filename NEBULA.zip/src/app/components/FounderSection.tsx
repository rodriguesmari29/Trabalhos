import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef } from "react";
import { Instagram, Twitter, Linkedin } from "lucide-react";

export function FounderSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-32 px-6">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#FF2E9F]/5 to-transparent" />

      <div className="max-w-7xl mx-auto relative">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-[#FF2E9F] to-[#FF79C6] bg-clip-text text-transparent">
            Visão Criativa
          </h2>
          <div className="h-1 w-32 mx-auto bg-gradient-to-r from-transparent via-[#FF2E9F] to-transparent" />
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="relative rounded-2xl overflow-hidden border-2 border-[#FF2E9F]/30 shadow-[0_0_50px_rgba(255,46,159,0.3)]">
              <img
                src="https://images.unsplash.com/photo-1580046939256-c377c5b099f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800"
                alt="Mariana Cruz"
                className="w-full aspect-[3/4] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent" />
            </div>
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-[#FF2E9F] rounded-full blur-3xl opacity-30" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <h3 className="text-4xl font-bold mb-2 text-[#F5F5F5]">Mariana Cruz</h3>
            <p className="text-xl text-[#FF2E9F] mb-6">Fundadora & Diretora Criativa</p>

            <div className="space-y-4 text-gray-400 mb-8">
              <p className="leading-relaxed">
                Mariana Cruz iniciou sua trajetória no desenvolvimento de jogos ainda adolescente,
                unindo design, programação e storytelling para criar experiências únicas.
              </p>
              <p className="leading-relaxed">
                Hoje lidera a Nebula com foco em inovação visual, direção criativa e experiências
                imersivas que redefinem os limites da narrativa interativa.
              </p>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-[#FF2E9F] rounded-full mt-2" />
                <div>
                  <p className="text-[#F5F5F5]">2018 - Fundou a Nebula Studio</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-[#FF2E9F] rounded-full mt-2" />
                <div>
                  <p className="text-[#F5F5F5]">2020 - Lançamento de Eclipse Protocol</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-[#FF2E9F] rounded-full mt-2" />
                <div>
                  <p className="text-[#F5F5F5]">2023 - Prêmio de Melhor Direção Criativa</p>
                </div>
              </div>
            </div>

            <div className="flex gap-4">
              <a href="#" className="w-12 h-12 bg-[#161616] border border-[#FF2E9F]/30 rounded-lg flex items-center justify-center hover:bg-[#FF2E9F] hover:scale-110 transition-all hover:shadow-[0_0_20px_rgba(255,46,159,0.5)]">
                <Instagram size={20} />
              </a>
              <a href="#" className="w-12 h-12 bg-[#161616] border border-[#FF2E9F]/30 rounded-lg flex items-center justify-center hover:bg-[#FF2E9F] hover:scale-110 transition-all hover:shadow-[0_0_20px_rgba(255,46,159,0.5)]">
                <Twitter size={20} />
              </a>
              <a href="#" className="w-12 h-12 bg-[#161616] border border-[#FF2E9F]/30 rounded-lg flex items-center justify-center hover:bg-[#FF2E9F] hover:scale-110 transition-all hover:shadow-[0_0_20px_rgba(255,46,159,0.5)]">
                <Linkedin size={20} />
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
