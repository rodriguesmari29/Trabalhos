import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef } from "react";
import { Trophy, MapPin, Calendar } from "lucide-react";

const events = [
  {
    name: "Gamescom Latam",
    year: "2025",
    location: "São Paulo, Brasil",
    achievement: "Melhor Jogo Indie",
    image: "https://images.unsplash.com/photo-1535391879778-3bae11d29a24?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
  {
    name: "Brasil Game Show",
    year: "2024",
    location: "São Paulo, Brasil",
    achievement: "Jogo Mais Aguardado",
    image: "https://images.unsplash.com/photo-1682933572177-4d853d9d8f17?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
  {
    name: "Tokyo Game Show",
    year: "2024",
    location: "Tóquio, Japão",
    achievement: "Destaque Internacional",
    image: "https://images.unsplash.com/photo-1761956424993-ec18823d462a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
];

export function EventsSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-32 px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-[#FF2E9F] to-[#FF79C6] bg-clip-text text-transparent">
            Eventos & Premiações
          </h2>
          <div className="h-1 w-32 mx-auto bg-gradient-to-r from-transparent via-[#FF2E9F] to-transparent mb-8" />
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Presença global nos maiores eventos de games do mundo
          </p>
        </motion.div>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-[#FF2E9F] via-[#FF79C6] to-[#FF2E9F] hidden md:block" />

          <div className="space-y-12">
            {events.map((event, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                className={`flex flex-col md:flex-row gap-8 items-center ${
                  index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                }`}
              >
                <div className="flex-1">
                  <div className="bg-[#161616] border border-[#FF2E9F]/20 rounded-2xl overflow-hidden hover:border-[#FF2E9F]/50 transition-all hover:shadow-[0_0_40px_rgba(255,46,159,0.3)] group">
                    <div className="relative overflow-hidden aspect-video">
                      <img
                        src={event.image}
                        alt={event.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#161616] via-transparent to-transparent" />
                    </div>
                    <div className="p-6">
                      <div className="flex items-center gap-2 text-[#FF79C6] mb-2">
                        <Calendar size={16} />
                        <span className="text-sm">{event.year}</span>
                      </div>
                      <h3 className="text-2xl font-bold mb-3 text-[#F5F5F5]">{event.name}</h3>
                      <div className="flex items-center gap-2 text-gray-400 mb-4">
                        <MapPin size={16} />
                        <span>{event.location}</span>
                      </div>
                      <div className="flex items-center gap-3 bg-[#050505] border border-[#FF2E9F]/30 rounded-lg p-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-[#FF2E9F] to-[#FF79C6] rounded-lg flex items-center justify-center">
                          <Trophy size={24} className="text-white" />
                        </div>
                        <div>
                          <div className="text-xs text-gray-500 uppercase mb-1">Premiação</div>
                          <div className="font-bold text-[#FF2E9F]">{event.achievement}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Timeline dot */}
                <div className="hidden md:block relative z-10">
                  <div className="w-6 h-6 bg-[#FF2E9F] rounded-full border-4 border-[#050505] shadow-[0_0_20px_rgba(255,46,159,0.5)]" />
                </div>

                <div className="flex-1" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
