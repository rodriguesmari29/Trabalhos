import { motion } from "motion/react";
import { Play, Rocket } from "lucide-react";

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Video background effect */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1672872476232-da16b45c9001?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1920"
          alt="Futuristic city"
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#050505]/80 via-[#050505]/50 to-[#050505]" />
      </div>

      {/* Neon glow effects */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#FF2E9F] rounded-full blur-[150px] opacity-20 animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#FF79C6] rounded-full blur-[150px] opacity-20 animate-pulse" style={{ animationDelay: '1s' }} />

      <div className="relative z-10 text-center px-6 max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          {/* Logo */}
          <div className="mb-8">
            <h1 className="text-8xl md:text-9xl font-bold mb-4 bg-gradient-to-r from-[#FF2E9F] to-[#FF79C6] bg-clip-text text-transparent animate-pulse">
              NEBULA
            </h1>
            <div className="h-1 w-32 mx-auto bg-gradient-to-r from-transparent via-[#FF2E9F] to-transparent" />
          </div>

          <motion.h2
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
            className="text-3xl md:text-5xl mb-8 text-[#F5F5F5]"
          >
            Criamos universos além da imaginação.
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1, duration: 1 }}
            className="text-xl text-gray-400 mb-12 max-w-3xl mx-auto"
          >
            Desenvolvedora de jogos AAA focada em experiências cinematográficas e mundos imersivos
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.5, duration: 0.8 }}
            className="flex flex-col sm:flex-row gap-6 justify-center"
          >
            <button className="group relative px-8 py-4 bg-gradient-to-r from-[#FF2E9F] to-[#FF79C6] text-white rounded-lg overflow-hidden transition-all hover:scale-105 hover:shadow-[0_0_30px_rgba(255,46,159,0.5)]">
              <span className="relative z-10 flex items-center gap-2 justify-center">
                <Play size={20} />
                Conheça nossos jogos
              </span>
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform" />
            </button>

            <button className="group px-8 py-4 border-2 border-[#FF2E9F] text-[#FF2E9F] rounded-lg transition-all hover:bg-[#FF2E9F] hover:text-white hover:scale-105 hover:shadow-[0_0_30px_rgba(255,46,159,0.3)]">
              <span className="flex items-center gap-2 justify-center">
                <Rocket size={20} />
                Ver próximos lançamentos
              </span>
            </button>
          </motion.div>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2"
        >
          <div className="w-6 h-10 border-2 border-[#FF2E9F] rounded-full p-1">
            <motion.div
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="w-1.5 h-1.5 bg-[#FF2E9F] rounded-full mx-auto"
            />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
