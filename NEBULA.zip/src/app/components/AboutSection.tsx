import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef } from "react";
import { Users, Trophy, Gamepad2, Sparkles } from "lucide-react";

const stats = [
  { icon: Users, value: "+20M", label: "Jogadores" },
  { icon: Gamepad2, value: "10", label: "Jogos Publicados" },
  { icon: Trophy, value: "5", label: "Premiações" },
  { icon: Sparkles, value: "São Paulo", label: "Estúdio Criativo" },
];

export function AboutSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-32 px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-[#FF2E9F] to-[#FF79C6] bg-clip-text text-transparent">
            Sobre a Nebula
          </h2>
          <div className="h-1 w-32 mx-auto bg-gradient-to-r from-transparent via-[#FF2E9F] to-transparent mb-8" />
          <p className="text-xl text-gray-400 max-w-4xl mx-auto leading-relaxed">
            A Nebula é uma desenvolvedora de jogos focada em criar experiências cinematográficas,
            mundos imersivos e narrativas emocionantes para a nova geração de jogadores.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className="relative group"
            >
              <div className="bg-[#161616] border border-[#FF2E9F]/20 rounded-2xl p-8 backdrop-blur-sm hover:border-[#FF2E9F]/50 transition-all hover:shadow-[0_0_30px_rgba(255,46,159,0.2)] hover:scale-105">
                <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-[#FF2E9F]/5 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="relative">
                  <div className="w-16 h-16 mb-4 mx-auto bg-gradient-to-br from-[#FF2E9F] to-[#FF79C6] rounded-xl flex items-center justify-center shadow-[0_0_20px_rgba(255,46,159,0.3)]">
                    <stat.icon size={32} className="text-white" />
                  </div>
                  <motion.div
                    initial={{ scale: 0.5 }}
                    animate={isInView ? { scale: 1 } : {}}
                    transition={{ duration: 0.5, delay: 0.5 + index * 0.1 }}
                    className="text-4xl font-bold mb-2 text-[#FF2E9F]"
                  >
                    {stat.value}
                  </motion.div>
                  <div className="text-gray-400">{stat.label}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
