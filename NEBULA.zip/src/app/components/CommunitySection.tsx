import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef, useState } from "react";
import { MessageCircle, Users, Mail, Send } from "lucide-react";

const communityPosts = [
  {
    user: "NebulaFan_BR",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=1",
    message: "Shadow Reborn é simplesmente incrível! Melhor stealth game que já joguei!",
    time: "2 horas atrás",
  },
  {
    user: "GamerPro2024",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=2",
    message: "Mal posso esperar pelo Project Aether! A Nebula sempre entrega qualidade.",
    time: "5 horas atrás",
  },
  {
    user: "CosmicPlayer",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=3",
    message: "Last Horizon me fez chorar com aquela história. Obra-prima absoluta!",
    time: "1 dia atrás",
  },
];

export function CommunitySection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [email, setEmail] = useState("");

  return (
    <section ref={ref} className="relative py-32 px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-[#FF2E9F] to-[#FF79C6] bg-clip-text text-transparent">
            Comunidade Nebula
          </h2>
          <div className="h-1 w-32 mx-auto bg-gradient-to-r from-transparent via-[#FF2E9F] to-transparent mb-8" />
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Junte-se a milhões de jogadores ao redor do mundo
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <div className="bg-[#161616] border border-[#FF2E9F]/20 rounded-2xl p-8 h-full">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-[#FF2E9F] to-[#FF79C6] rounded-xl flex items-center justify-center">
                  <MessageCircle size={24} className="text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-[#F5F5F5]">Feed da Comunidade</h3>
                  <p className="text-sm text-gray-400">
                    <span className="inline-flex items-center gap-1">
                      <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                      <span className="text-green-500 font-bold">152,847</span> jogadores online
                    </span>
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                {communityPosts.map((post, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
                    className="bg-[#050505] border border-[#FF2E9F]/10 rounded-xl p-4 hover:border-[#FF2E9F]/30 transition-all"
                  >
                    <div className="flex items-start gap-3">
                      <img
                        src={post.avatar}
                        alt={post.user}
                        className="w-10 h-10 rounded-full border-2 border-[#FF2E9F]/30"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-bold text-[#F5F5F5] text-sm">{post.user}</span>
                          <span className="text-xs text-gray-500">{post.time}</span>
                        </div>
                        <p className="text-gray-300 text-sm leading-relaxed">{post.message}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              <button className="w-full mt-6 py-3 bg-[#050505] border border-[#FF2E9F]/30 text-[#FF2E9F] rounded-lg hover:bg-[#FF2E9F] hover:text-white transition-all hover:scale-105">
                Ver mais comentários
              </button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <div className="bg-[#161616] border border-[#FF2E9F]/20 rounded-2xl p-8 h-full">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-[#FF2E9F] to-[#FF79C6] rounded-xl flex items-center justify-center">
                  <Mail size={24} className="text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-[#F5F5F5]">Newsletter</h3>
                  <p className="text-sm text-gray-400">Fique por dentro das novidades</p>
                </div>
              </div>

              <p className="text-gray-400 mb-6 leading-relaxed">
                Receba em primeira mão notícias sobre lançamentos, eventos exclusivos,
                beta tests e muito mais diretamente no seu email.
              </p>

              <form onSubmit={(e) => e.preventDefault()} className="space-y-4">
                <div>
                  <label htmlFor="email" className="block text-sm text-gray-400 mb-2">
                    Seu melhor email
                  </label>
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="seu@email.com"
                    className="w-full px-4 py-3 bg-[#050505] border border-[#FF2E9F]/30 rounded-lg text-[#F5F5F5] placeholder-gray-500 focus:border-[#FF2E9F] focus:outline-none focus:ring-2 focus:ring-[#FF2E9F]/20 transition-all"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-gradient-to-r from-[#FF2E9F] to-[#FF79C6] text-white rounded-lg hover:shadow-[0_0_30px_rgba(255,46,159,0.5)] transition-all hover:scale-105 flex items-center justify-center gap-2"
                >
                  <Send size={18} />
                  Inscrever-se
                </button>
              </form>

              <div className="mt-8 pt-8 border-t border-[#FF2E9F]/10">
                <p className="text-sm text-gray-500 mb-4">Benefícios da newsletter:</p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-gray-400">
                    <div className="w-1.5 h-1.5 bg-[#FF2E9F] rounded-full" />
                    <span>Acesso antecipado a beta tests</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-400">
                    <div className="w-1.5 h-1.5 bg-[#FF2E9F] rounded-full" />
                    <span>Descontos exclusivos</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-400">
                    <div className="w-1.5 h-1.5 bg-[#FF2E9F] rounded-full" />
                    <span>Behind the scenes do desenvolvimento</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-400">
                    <div className="w-1.5 h-1.5 bg-[#FF2E9F] rounded-full" />
                    <span>Participação em eventos VIP</span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
