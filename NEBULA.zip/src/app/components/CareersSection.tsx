import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef } from "react";
import { Palette, Layers, Code, Box, Sparkles, QrCode } from "lucide-react";
import qrCodeImage from "../../imports/QRCODE.png";

const positions = [
  { icon: Palette, title: "Game Designer", description: "Criação de mecânicas e sistemas de gameplay" },
  { icon: Layers, title: "Concept Artist", description: "Desenvolvimento visual de mundos e personagens" },
  { icon: Code, title: "UI/UX Designer", description: "Interface e experiência do usuário" },
  { icon: Box, title: "3D Artist", description: "Modelagem e texturização de assets" },
  { icon: Sparkles, title: "Motion Designer", description: "Animações e efeitos visuais" },
];

export function CareersSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-32 px-6 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#FF2E9F]/10 to-transparent" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#FF2E9F] rounded-full blur-[150px] opacity-10" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#FF79C6] rounded-full blur-[150px] opacity-10" />

      <div className="max-w-7xl mx-auto relative">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-[#FF2E9F] to-[#FF79C6] bg-clip-text text-transparent">
            Trabalhe na Nebula
          </h2>
          <div className="h-1 w-32 mx-auto bg-gradient-to-r from-transparent via-[#FF2E9F] to-transparent mb-8" />
          <p className="text-2xl md:text-3xl text-[#F5F5F5] mb-4">
            Estamos procurando os próximos artistas do futuro.
          </p>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Junte-se a uma equipe de visionários que está redefinindo a indústria de jogos
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6 mb-16">
          {positions.map((position, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className="group"
            >
              <div className="bg-[#161616] border border-[#FF2E9F]/20 rounded-2xl p-6 hover:border-[#FF2E9F]/50 transition-all hover:shadow-[0_0_30px_rgba(255,46,159,0.3)] hover:scale-105 h-full">
                <div className="w-14 h-14 mb-4 bg-gradient-to-br from-[#FF2E9F] to-[#FF79C6] rounded-xl flex items-center justify-center shadow-[0_0_20px_rgba(255,46,159,0.3)] group-hover:shadow-[0_0_30px_rgba(255,46,159,0.5)] transition-all">
                  <position.icon size={28} className="text-white" />
                </div>
                <h3 className="text-lg font-bold mb-2 text-[#F5F5F5]">{position.title}</h3>
                <p className="text-sm text-gray-400 leading-relaxed">{position.description}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="bg-[#161616] border-2 border-[#FF2E9F]/30 rounded-3xl p-12 backdrop-blur-sm shadow-[0_0_60px_rgba(255,46,159,0.2)]"
        >
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl font-bold mb-6 text-[#F5F5F5]">
                Pronto para criar o futuro dos jogos?
              </h3>
              <p className="text-lg text-gray-400 mb-8 leading-relaxed">
                Escaneie o QR Code e envie seu portfólio para fazer parte da Nebula.
                Estamos em busca de talentos apaixonados por criar experiências inesquecíveis.
              </p>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-[#FF2E9F] rounded-full" />
                  <span className="text-gray-300">Trabalhe em projetos AAA</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-[#FF2E9F] rounded-full" />
                  <span className="text-gray-300">Equipe internacional</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-[#FF2E9F] rounded-full" />
                  <span className="text-gray-300">Benefícios competitivos</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-[#FF2E9F] rounded-full" />
                  <span className="text-gray-300">Modelo híbrido</span>
                </div>
              </div>
            </div>

            <div className="flex justify-center">
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="relative group"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-[#FF2E9F] to-[#FF79C6] rounded-3xl blur-xl opacity-50 group-hover:opacity-70 transition-opacity" />
                <div className="relative bg-white rounded-3xl p-8 border-4 border-[#FF2E9F] shadow-[0_0_40px_rgba(255,46,159,0.4)]">
                  <div className="w-64 h-64 flex flex-col items-center justify-center">
                    <img
                      src={qrCodeImage}
                      alt="QR Code - Envie seu portfólio"
                      className="w-52 h-52 mb-3"
                    />
                    <p className="text-[#050505] font-bold text-sm text-center">
                      Escaneie para enviar<br />seu portfólio
                    </p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
