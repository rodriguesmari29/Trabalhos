import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef, useState, useEffect } from "react";
import { Rocket, Clock } from "lucide-react";

const gamesInDev = [
  {
    title: "Project Aether",
    type: "MMORPG Futurista",
    description: "MMORPG de próxima geração com mundos persistentes e narrativa emergente",
    releaseDate: "2027-06-15",
    progress: 65,
    image: "https://images.unsplash.com/photo-1651421569877-9f714e7822ba?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
  {
    title: "Neon Ronin",
    type: "Hack and Slash Cyberpunk",
    description: "Hack and slash cyberpunk com combate fluido e visual neon-noir",
    releaseDate: "2026-11-20",
    progress: 82,
    image: "https://images.unsplash.com/photo-1600998837340-4887228e311f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
];

function CountdownTimer({ targetDate }: { targetDate: string }) {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0 });

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date().getTime();
      const target = new Date(targetDate).getTime();
      const difference = target - now;

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
        });
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [targetDate]);

  return (
    <div className="flex gap-4 justify-center">
      {Object.entries(timeLeft).map(([unit, value]) => (
        <div key={unit} className="text-center">
          <div className="w-16 h-16 bg-[#050505] border border-[#FF2E9F]/30 rounded-lg flex items-center justify-center mb-1">
            <span className="text-2xl font-bold text-[#FF2E9F]">{value}</span>
          </div>
          <div className="text-xs text-gray-500 uppercase">{unit}</div>
        </div>
      ))}
    </div>
  );
}

export function InDevelopmentSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-32 px-6">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#FF2E9F]/5 to-transparent" />

      <div className="max-w-7xl mx-auto relative">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-[#FF2E9F] to-[#FF79C6] bg-clip-text text-transparent">
            Em Desenvolvimento
          </h2>
          <div className="h-1 w-32 mx-auto bg-gradient-to-r from-transparent via-[#FF2E9F] to-transparent mb-8" />
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Os próximos universos que você vai explorar
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {gamesInDev.map((game, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className="group relative"
            >
              <div className="bg-[#161616] border border-[#FF2E9F]/20 rounded-2xl overflow-hidden hover:border-[#FF2E9F]/50 transition-all hover:shadow-[0_0_40px_rgba(255,46,159,0.3)]">
                <div className="relative overflow-hidden aspect-video">
                  <img
                    src={game.image}
                    alt={game.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#161616] via-transparent to-transparent" />

                  <div className="absolute top-4 left-4 flex items-center gap-2 bg-[#FF2E9F] px-4 py-2 rounded-lg">
                    <Rocket size={16} />
                    <span className="font-bold text-sm">EM BREVE</span>
                  </div>
                </div>

                <div className="p-6">
                  <div className="text-sm text-[#FF79C6] mb-2">{game.type}</div>
                  <h3 className="text-2xl font-bold mb-3 text-[#F5F5F5]">{game.title}</h3>
                  <p className="text-gray-400 mb-6 leading-relaxed">{game.description}</p>

                  <div className="mb-6">
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-400">Progresso de Desenvolvimento</span>
                      <span className="text-[#FF2E9F] font-bold">{game.progress}%</span>
                    </div>
                    <div className="w-full h-2 bg-[#050505] rounded-full overflow-hidden border border-[#FF2E9F]/20">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={isInView ? { width: `${game.progress}%` } : {}}
                        transition={{ duration: 1.5, delay: 0.5 + index * 0.2 }}
                        className="h-full bg-gradient-to-r from-[#FF2E9F] to-[#FF79C6] rounded-full shadow-[0_0_10px_rgba(255,46,159,0.5)]"
                      />
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="flex items-center gap-2 text-sm text-gray-400 mb-3">
                      <Clock size={16} />
                      <span>Lançamento previsto</span>
                    </div>
                    <CountdownTimer targetDate={game.releaseDate} />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
