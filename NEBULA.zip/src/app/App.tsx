import { motion } from "motion/react";
import { Sparkles, Trophy, Users, Gamepad2, Play, Rocket, Briefcase, QrCode, Instagram, Twitter, Youtube, Twitch } from "lucide-react";
import { HeroSection } from "./components/HeroSection";
import { AboutSection } from "./components/AboutSection";
import { FounderSection } from "./components/FounderSection";
import { GamesSection } from "./components/GamesSection";
import { InDevelopmentSection } from "./components/InDevelopmentSection";
import { EventsSection } from "./components/EventsSection";
import { CareersSection } from "./components/CareersSection";
import { CommunitySection } from "./components/CommunitySection";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="w-full min-h-screen bg-[#050505] text-[#F5F5F5] overflow-x-hidden">
      {/* Animated background particles */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-[#FF2E9F]/5 via-transparent to-[#FF2E9F]/10" />
        {[...Array(50)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-[#FF2E9F] rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.2, 0.8, 0.2],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <div className="relative z-10">
        <HeroSection />
        <AboutSection />
        <FounderSection />
        <GamesSection />
        <InDevelopmentSection />
        <EventsSection />
        <CareersSection />
        <CommunitySection />
        <Footer />
      </div>
    </div>
  );
}
