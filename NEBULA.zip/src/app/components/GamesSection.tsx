import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef } from "react";
import { Play, Star, Monitor, Gamepad2 } from "lucide-react";

const games = [
  {
    title: "Eclipse Protocol",
    genre: "Sci-Fi RPG",
    description: "RPG futurista sobre corporações galácticas em busca de domínio universal",
    rating: 9.2,
    platforms: ["PC", "PS5", "Xbox"],
    image: "https://images.unsplash.com/photo-1649256308437-e93443143e3a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
  {
    title: "Shadow Reborn",
    genre: "Stealth Cyberpunk",
    description: "Jogo stealth cyberpunk focado em espionagem e infiltração corporativa",
    rating: 8.8,
    platforms: ["PC", "PS5"],
    image: "https://images.unsplash.com/photo-1642345843526-6279c8880a49?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
  {
    title: "Last Horizon",
    genre: "Survival Open World",
    description: "Survival de mundo aberto em um planeta abandonado repleto de mistérios",
    rating: 9.5,
    platforms: ["PC", "PS5", "Xbox", "Switch"],
    image: "https://images.unsplash.com/photo-1579900205441-8b66ccb14569?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
  },
];

export function GamesSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-32 px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-[#FF2E9F] to-[#FF79C6] bg-clip-text text-transparent">
            Nossos Jogos
          </h2>
          <div className="h-1 w-32 mx-auto bg-gradient-to-r from-transparent via-[#FF2E9F] to-transparent mb-8" />
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Experiências cinematográficas que redefinem os limites da narrativa interativa
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {games.map((game, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className="group relative"
            >
              <div className="bg-[#161616] border border-[#FF2E9F]/20 rounded-2xl overflow-hidden hover:border-[#FF2E9F]/50 transition-all hover:shadow-[0_0_40px_rgba(255,46,159,0.3)] hover:scale-[1.02]">
                <div className="relative overflow-hidden aspect-video">
                  <img
                    src={game.image}
                    alt={game.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#161616] via-transparent to-transparent" />

                  <div className="absolute top-4 right-4 flex items-center gap-2 bg-black/80 backdrop-blur-sm px-3 py-1.5 rounded-lg border border-[#FF2E9F]/30">
                    <Star size={16} className="text-[#FF2E9F] fill-[#FF2E9F]" />
                    <span className="font-bold">{game.rating}</span>
                  </div>

                  <button className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/50 backdrop-blur-sm">
                    <div className="w-16 h-16 bg-[#FF2E9F] rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(255,46,159,0.5)]">
                      <Play size={24} className="text-white ml-1" />
                    </div>
                  </button>
                </div>

                <div className="p-6">
                  <div className="text-sm text-[#FF79C6] mb-2">{game.genre}</div>
                  <h3 className="text-2xl font-bold mb-3 text-[#F5F5F5]">{game.title}</h3>
                  <p className="text-gray-400 mb-4 leading-relaxed">{game.description}</p>

                  <div className="flex items-center gap-2 mb-4 flex-wrap">
                    {game.platforms.map((platform, i) => (
                      <span
                        key={i}
                        className="px-3 py-1 bg-[#050505] border border-[#FF2E9F]/20 rounded-lg text-sm text-gray-300"
                      >
                        {platform}
                      </span>
                    ))}
                  </div>

                  <button className="w-full py-3 bg-gradient-to-r from-[#FF2E9F] to-[#FF79C6] text-white rounded-lg hover:shadow-[0_0_20px_rgba(255,46,159,0.5)] transition-all hover:scale-105 flex items-center justify-center gap-2">
                    <Play size={18} />
                    Assistir Trailer
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
