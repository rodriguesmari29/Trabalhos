import { motion } from "motion/react";
import { Instagram, Twitter, Youtube, Twitch, Linkedin, Github } from "lucide-react";

export function Footer() {
  return (
    <footer className="relative border-t border-[#FF2E9F]/20 bg-[#050505]">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          <div className="md:col-span-2">
            <motion.div
              animate={{
                textShadow: [
                  "0 0 20px rgba(255, 46, 159, 0.3)",
                  "0 0 30px rgba(255, 46, 159, 0.5)",
                  "0 0 20px rgba(255, 46, 159, 0.3)",
                ]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <h3 className="text-5xl font-bold mb-4 bg-gradient-to-r from-[#FF2E9F] to-[#FF79C6] bg-clip-text text-transparent">
                NEBULA
              </h3>
            </motion.div>
            <p className="text-gray-400 mb-6 leading-relaxed max-w-md">
              Criando universos além da imaginação. Desenvolvedora de jogos AAA focada em
              experiências cinematográficas e mundos imersivos.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-10 h-10 bg-[#161616] border border-[#FF2E9F]/30 rounded-lg flex items-center justify-center hover:bg-[#FF2E9F] hover:scale-110 transition-all hover:shadow-[0_0_20px_rgba(255,46,159,0.5)]">
                <Instagram size={18} />
              </a>
              <a href="#" className="w-10 h-10 bg-[#161616] border border-[#FF2E9F]/30 rounded-lg flex items-center justify-center hover:bg-[#FF2E9F] hover:scale-110 transition-all hover:shadow-[0_0_20px_rgba(255,46,159,0.5)]">
                <Twitter size={18} />
              </a>
              <a href="#" className="w-10 h-10 bg-[#161616] border border-[#FF2E9F]/30 rounded-lg flex items-center justify-center hover:bg-[#FF2E9F] hover:scale-110 transition-all hover:shadow-[0_0_20px_rgba(255,46,159,0.5)]">
                <Youtube size={18} />
              </a>
              <a href="#" className="w-10 h-10 bg-[#161616] border border-[#FF2E9F]/30 rounded-lg flex items-center justify-center hover:bg-[#FF2E9F] hover:scale-110 transition-all hover:shadow-[0_0_20px_rgba(255,46,159,0.5)]">
                <Twitch size={18} />
              </a>
              <a href="#" className="w-10 h-10 bg-[#161616] border border-[#FF2E9F]/30 rounded-lg flex items-center justify-center hover:bg-[#FF2E9F] hover:scale-110 transition-all hover:shadow-[0_0_20px_rgba(255,46,159,0.5)]">
                <Linkedin size={18} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-4 text-[#F5F5F5]">Jogos</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-[#FF2E9F] transition-colors">Eclipse Protocol</a></li>
              <li><a href="#" className="text-gray-400 hover:text-[#FF2E9F] transition-colors">Shadow Reborn</a></li>
              <li><a href="#" className="text-gray-400 hover:text-[#FF2E9F] transition-colors">Last Horizon</a></li>
              <li><a href="#" className="text-gray-400 hover:text-[#FF2E9F] transition-colors">Em Desenvolvimento</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-4 text-[#F5F5F5]">Empresa</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-[#FF2E9F] transition-colors">Sobre Nós</a></li>
              <li><a href="#" className="text-gray-400 hover:text-[#FF2E9F] transition-colors">Carreiras</a></li>
              <li><a href="#" className="text-gray-400 hover:text-[#FF2E9F] transition-colors">Imprensa</a></li>
              <li><a href="#" className="text-gray-400 hover:text-[#FF2E9F] transition-colors">Contato</a></li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-[#FF2E9F]/10">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-500 text-sm">
              © 2026 Nebula Games Studio. Todos os direitos reservados.
            </p>
            <div className="flex gap-6 text-sm">
              <a href="#" className="text-gray-500 hover:text-[#FF2E9F] transition-colors">Privacidade</a>
              <a href="#" className="text-gray-500 hover:text-[#FF2E9F] transition-colors">Termos de Uso</a>
              <a href="#" className="text-gray-500 hover:text-[#FF2E9F] transition-colors">Suporte</a>
            </div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#FF2E9F] to-transparent opacity-50" />
    </footer>
  );
}
